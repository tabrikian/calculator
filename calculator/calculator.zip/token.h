#include <stdbool.h>
#include <stdlib.h>

typedef struct token_t {
	bool is_num;
	bool is_operator; //contains also ( and )
	bool is_function;
	int num;
	char _operator;
	char* function;
} token_t; 

token_t* create_by_num(int num);
token_t* create_by_oprator(char _operator);
token_t* create_by_function(char* function);
int delete_token(token_t* token);
